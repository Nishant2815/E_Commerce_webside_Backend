package com.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.pms.dto.ProductDTO;
import com.pms.service.ProductService;

@RestController
@RequestMapping("/pms")
public class ProductController {

    @Autowired
    private ProductService ps;

    // Save Product
    @PostMapping
    public ResponseEntity<ProductDTO> save(@RequestBody ProductDTO pd) {

        ProductDTO pdto = ps.saveProduct(pd);

        return new ResponseEntity<>(pdto, HttpStatus.CREATED);
    }

    // Get All Products
    @GetMapping
    public ResponseEntity<List<ProductDTO>> viewAll() {

        List<ProductDTO> allP = ps.getAllProduct();

        return ResponseEntity.ok(allP);
    }

    // Get Product By ID
    @GetMapping("/{id}")
    public ResponseEntity<ProductDTO> viewProduct(@PathVariable int id) {

        ProductDTO pd = ps.getProductById(id);

        return ResponseEntity.ok(pd);
    }

    // Delete Product
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable int id) {

        ps.deleteProduct(id);

        return new ResponseEntity<>("Product Deleted", HttpStatus.OK);
    }

    // Update Product
    @PutMapping("/{id}")
    public ResponseEntity<ProductDTO> update(@PathVariable int id, @RequestBody ProductDTO pd) {

        ProductDTO upProduct = ps.updateProduct(id, pd);

        return ResponseEntity.ok(upProduct);
    }
}