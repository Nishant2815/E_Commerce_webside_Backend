package com.pms.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.dto.ProductDTO;
import com.pms.entity.Product;
import com.pms.mapper.ProductMapper;
import com.pms.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    ProductRepository pr;

    @Override
    public ProductDTO saveProduct(ProductDTO pdto) {

        Product p = ProductMapper.mapToProduct(pdto);

        Product savedProduct = pr.save(p);

        return ProductMapper.mapToProductDTO(savedProduct);
    }

    @Override
    public List<ProductDTO> getAllProduct() {

        List<Product> plist = pr.findAll();

        return plist.stream()
                .map(ProductMapper::mapToProductDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ProductDTO getProductById(int id) {

        Product p = pr.findById(id).get();

        return ProductMapper.mapToProductDTO(p);
    }

    @Override
    public String deleteProduct(int id) {

        pr.deleteById(id);

        return "Product Deleted";
    }

    @Override
    public ProductDTO updateProduct(int id, ProductDTO pd) {

        Product p = pr.findById(id).get();

        p.setName(pd.getName());
        p.setCost(pd.getCost());
        p.setCategory(pd.getCategory());
        p.setQty(pd.getQty());

        Product updated = pr.save(p);

        return ProductMapper.mapToProductDTO(updated);
    }
}