package com.pms.service;

import java.util.List;
import com.pms.dto.ProductDTO;

public interface ProductService {

    ProductDTO saveProduct(ProductDTO pd);

    List<ProductDTO> getAllProduct();

    ProductDTO getProductById(int id);

    String deleteProduct(int id);

    ProductDTO updateProduct(int id, ProductDTO pd);
}